---
payment_methods:
  - name: "Visa"
    image_url: "/images/payment/visa.png"
  - name: "MasterCard"
    image_url: "/images/payment/mastercard.png"
  - name: "Express"
    image_url: "/images/payment/express.png"
  - name: "Bkash"
    image_url: "/images/payment/bkash.png"
  - name: "Nagad"
    image_url: "/images/payment/nagad.png"
  - name: "Upay"
    image_url: "/images/payment/upay.png"

estimated_delivery: "Est. Delivery between 0 - 3 days"
---