---
enable: true
title: "consigue los mejores tips
para tu skate por 25% de descuento"
sub_title: "oferta de esta semana"
image: "/images/call-to-action.png"
description: "Suscribete y recibe todas nuestras novedades"
button:
  enable: true
  label: "Comunidad"
  link: "/products"
---
