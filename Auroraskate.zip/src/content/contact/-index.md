---
title: "Entra en la comunidad"
meta_title: "Comunidad"
description: "this is meta description"
draft: false

#Contact Options
contact_meta:
  - name: "Direccion"
    contact: "123 Main Street, Anytown, </br> CA 12335 - USA"

  - name: "Correo"
    contact: "yourmail@AuroraSkate.com </br> support@AuroraSkate.com"

  - name: "Telefono"
    contact: "Mobile: (08) 123 456 789 </br> Hotline: 1009 678 456"

  - name: "Horario de atencion"
    contact: "Abiertos 10am-8pm </br>"
---
